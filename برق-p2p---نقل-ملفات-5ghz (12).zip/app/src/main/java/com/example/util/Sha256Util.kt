package com.example.util

import android.content.ContentResolver
import android.net.Uri
import com.example.model.TransferFileItem
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.security.MessageDigest

object Sha256Util {

    const val EMPTY_BYTES_SHA256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    const val EMPTY_DIR_SHA256 = "DIR_EMPTY"

    private val HEX_CHARS = "0123456789abcdef".toCharArray()

    /**
     * Streams a File or Content Uri in 256 KB blocks to compute its exact SHA-256 hex digest
     * without loading the entire file into memory.
     */
    fun computeSha256(resolver: ContentResolver, item: TransferFileItem): String {
        if (item.isDirectory) return EMPTY_DIR_SHA256
        if (item.sizeBytes == 0L) return EMPTY_BYTES_SHA256
        val local = item.localFile
        if (local != null && local.exists() && local.isFile) {
            return computeFileSha256(local)
        }
        val uri = item.uri ?: return ""
        return computeUriSha256(resolver, uri)
    }

    fun computeFileSha256(file: File): String {
        if (!file.exists()) return ""
        if (file.isDirectory) return EMPTY_DIR_SHA256
        if (file.length() == 0L) return EMPTY_BYTES_SHA256
        return try {
            FileInputStream(file).use { fis ->
                computeStreamSha256(fis)
            }
        } catch (_: Throwable) {
            ""
        }
    }

    fun computeUriSha256(resolver: ContentResolver, uri: Uri): String {
        return try {
            resolver.openInputStream(uri)?.use { stream ->
                computeStreamSha256(stream)
            } ?: ""
        } catch (_: Throwable) {
            ""
        }
    }

    private fun computeStreamSha256(stream: InputStream): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(256 * 1024)
        while (true) {
            val read = stream.read(buffer)
            if (read == -1) break
            if (read > 0) {
                digest.update(buffer, 0, read)
            }
        }
        return bytesToHex(digest.digest())
    }

    fun bytesToHex(bytes: ByteArray): String {
        val out = CharArray(bytes.size * 2)
        var i = 0
        for (b in bytes) {
            val v = b.toInt() and 0xFF
            out[i++] = HEX_CHARS[v ushr 4]
            out[i++] = HEX_CHARS[v and 0x0F]
        }
        return String(out)
    }
}
